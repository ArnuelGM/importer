<?php
	namespace excel;
	use Illuminate\Database\Capsule\Manager as DB;

	class ImportController {
		
		private $sheet;
		private $profile;

		public function __construct($profile, $sheet){
			$this->sheet = $sheet;
			$this->profile = $profile;
		}

		public function execute() {
			$table = $this->profile->table;
			$skypFirstRow = $this->profile->skip_first_row;
			$fields = (array) json_decode($this->profile->fields);
			$valueModel = array();

			$maxRows = $this->sheet->getHighestRow();
			$maxRows = 12422;

			// print_r($maxRows);
			// exit();
			$valueCount = 0;
			for ($row = 1; $row <= $maxRows; $row++) {
				if( $row == 1 && $skypFirstRow ) continue;
				$rowValue = array();
				foreach ($fields as $i => $value) {

					if($valueCount == 1000){
						$valueCount = 0;
						DB::table($table)->insert($valueModel);
						$valueModel = array();
					}

					$column = $i+1;
					$cell = $this->sheet->getCellByColumnAndRow($column, $row);
					$cellValue = $cell->getCalculatedValue();
					$insertValue = empty($cellValue) ? '' : $cellValue;
					$rowValue[$value] = $insertValue;
					$valueCount++;
				}
				array_push($valueModel, $rowValue);
			}
			$result = DB::table($table)->insert($valueModel);
			return ["data" => $valueModel, "result" => $result];
			// return $valueModel;
		}
	}