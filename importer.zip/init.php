<?php
	require_once 'vendor/autoload.php';
	require_once 'database/dbconfig.php';
	require_once 'excel/exlconfig.php';
	require_once 'filesystem/filesystem.php';